package com.example.niravbavishi.firebasedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference root;
    RequestQueue mRequestQueue;

    TextView textView;
    Button btn;
    EditText msgText;


    private ChildEventListener childEventListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



         textView = findViewById(R.id.textView);
         btn = findViewById(R.id.sendBtn);
         msgText = findViewById(R.id.currency_code);



        database = FirebaseDatabase.getInstance();
        root = database.getReference();


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getJSONData(msgText.getText().toString());

            }
        });



    }




    public void getJSONData(final String code){

        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }


        // Put this in the location where you want to make a JSON Request
        String url = "https://api.coindesk.com/v1/bpi/currentprice/"+ code +".json";
//        Toast.makeText(getApplicationContext(), url, Toast.LENGTH_LONG).show();
        JsonObjectRequest jsObjRequest =
                new JsonObjectRequest(
                        Request.Method.GET,
                        url,
                        null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                // Check that you went to the correct website
                                // by printing out the response

                                String current_rate;

                                try {
                                    Toast.makeText(getApplicationContext(), response.getJSONObject("bpi").getJSONObject(code).getString("rate"), Toast.LENGTH_LONG).show();
                                    current_rate = response.getJSONObject("bpi").getJSONObject(code).getString("rate");

                                    saveData(current_rate, code);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }



                                // Uncomment this code when you are ready to parse
                /*
                try {
                }
                catch (JSONException e) {
                    Log.d("", "JSON Error occurred");
                }
                */
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.e("" , error.toString());
                    }
                });
        mRequestQueue.add(jsObjRequest);


    }


    public void saveData(String price, String currency_code){


                Date d = new Date();
                SimpleDateFormat s = new SimpleDateFormat("hh:mm a");
                String date = s.format(d);

                String messagetext = msgText.getText().toString();

                if (messagetext.trim() != "" || messagetext.trim() != null) {



                    Currency curency1 = new Currency(price, date, currency_code);

                    root.child("abc").push().setValue(curency1);

                }else
                {

                    Toast.makeText(getApplicationContext(), "Please Write Something", Toast.LENGTH_LONG).show();

                }



    }



}
