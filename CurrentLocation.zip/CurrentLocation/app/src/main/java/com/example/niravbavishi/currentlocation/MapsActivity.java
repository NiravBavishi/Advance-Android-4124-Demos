package com.example.niravbavishi.currentlocation;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    //Elements


    // for location
    LocationManager locationManager;
    Location flagLocation = new Location(""), currentLocation = new Location("");
    private double currentDistance, previousDistance;

    private Location[] userLocations;

    //for permissions
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private Boolean mLocationPermissionGranted = false;


    // for firebase
    FirebaseDatabase database;
    DatabaseReference root;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Log.e("", "onCreate: Ok --------------------------------------------- ");
        Toast.makeText(this, "In On Create", Toast.LENGTH_SHORT).show();

        flagLocation.setLatitude(43.775447);
        flagLocation.setLongitude(-79.345615);

        getLocationPermission();

        //location array initiate

        for (int i=0; i<10; i++){

            userLocations[i] = new Location("");
            userLocations[i].setLatitude(43.775447 + (i * 100));
            userLocations[i].setLongitude(-79.345615  + (i * 100));

        }



        //firebase

        database = FirebaseDatabase.getInstance();
        root = database.getReference();
            //save flag location to firebase
        LocationDetails locationDetails = new LocationDetails("Flag", flagLocation.getLatitude(), flagLocation.getLongitude());

        root.child("FlagLocation").push().setValue(locationDetails);

    }


    private void getLocationPermission() {

        Log.d("", "getLocationPermission: Geting Permisson");

        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};

        if (ContextCompat.checkSelfPermission(this.getApplicationContext(), FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            if (ContextCompat.checkSelfPermission(this.getApplicationContext(), COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                mLocationPermissionGranted = true;
                //intialize map
                initMap();

            } else {

                ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);

            }


        } else {

            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);

        }

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        mLocationPermissionGranted = false;

        switch (requestCode) {

            case LOCATION_PERMISSION_REQUEST_CODE: {

                if (grantResults.length > 0) {

                    for (int i = 0; i < grantResults.length; i++) {

                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {

                            mLocationPermissionGranted = false;
                            return;

                        }

                    }
                    mLocationPermissionGranted = true;


                }

            }

        }

    }

    public void initMap() {


        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            Toast.makeText(this, "Returning", Toast.LENGTH_LONG).show();
            return;
        }

        if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {

            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                    locateMap(location);

                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });
        } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                    locateMap(location);

                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });

        } else {
            Toast.makeText(this, "No Location provider", Toast.LENGTH_LONG).show();
        }

    }

    private void locateMap(Location location){




        //get the latitude and longitude
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();

        LatLng latLng = new LatLng(latitude, longitude);

        Geocoder geocoder = new Geocoder(getApplicationContext());

        LatLng flagLatLng = new LatLng(flagLocation.getLatitude(), flagLocation.getLongitude());
        
        currentLocation.setLatitude(latitude);
        currentLocation.setLongitude(longitude);
        
        currentDistance = flagLocation.distanceTo(currentLocation);
        
        if (currentDistance > previousDistance){

            Toast.makeText(this, "you are moving away from flag", Toast.LENGTH_SHORT).show();
            
        }else if (currentDistance < previousDistance){

            Toast.makeText(this, "you are getting closer to flag", Toast.LENGTH_SHORT).show();

        }

        MarkerOptions flagMarker = new MarkerOptions();

        flagMarker.position(flagLatLng).title("Flag").icon(BitmapDescriptorFactory.fromResource(R.drawable.flag_map_marker));


        if(currentDistance > 50) {
            Toast.makeText(this, "Current Distance Is : " + currentDistance, Toast.LENGTH_SHORT).show();

            flagMarker.visible(false);

        }else {

            flagMarker.visible(true);

        }
        mMap.addMarker(flagMarker);



        previousDistance = currentDistance;

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f));


//                    try {
//
//                        List<Address> addressList =  geocoder.getFromLocation(latitude, longitude, 1);
//                        String currentAddress = addressList.get(0).getLocality() + " , ";
//                        currentAddress += addressList.get(0).getCountryName();
//
//
//                        Toast.makeText(MapsActivity.this, "In Network Provider", Toast.LENGTH_SHORT).show();
//                        Log.d("Tag Demo", "onLocationChanged: In Network Provider");
//
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                        Log.e("", "onLocationChanged: " + e.getMessage());
//                    }

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);

        // Add a marker in Sydney and move the camera
//        LatLng sydney = new LatLng(-34, 151);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 10.2f));
    }

    public void btnLoadDataClicked(View view) {

        Toast.makeText(this, "Load Data Clicked", Toast.LENGTH_LONG).show();

        for (int i=0; i<10; i++){

            LocationDetails locationDetails = new LocationDetails("Flag", userLocations[i].getLatitude(), userLocations[i].getLongitude());
            root.child("FlagLocation").push().setValue(locationDetails);

        }

    }

    public void btnShowDataClicked(View view) {

        Toast.makeText(this, "Show Data Clicked", Toast.LENGTH_LONG).show();

    }
}
