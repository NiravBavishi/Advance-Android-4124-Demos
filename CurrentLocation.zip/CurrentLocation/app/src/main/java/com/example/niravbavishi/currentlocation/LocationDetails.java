package com.example.niravbavishi.currentlocation;

import android.location.Location;

public class LocationDetails {

    private String title;
    private Double latitude;
    private Double longitude;


    public LocationDetails() {
    }


    public LocationDetails(String title, Double latitude, Double longitude) {
        this.title = title;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public LocationDetails(String title, Location location) {
        this.title = title;
        this.latitude = location.getLatitude();
        this.longitude = location.getLongitude();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}

