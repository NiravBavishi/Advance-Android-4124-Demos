package com.example.macstudent.diffbetweenlocationapp;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

public class MainActivity extends AppCompatActivity {


    private static final String TAG = "MainActivity";

    private  static final int ERROR_DIALOG_REQUEST = 9001;

    Button btnMap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        if (isServicesOk()){

            init();

        }

    }

    private void init(){
//        Toast.makeText(getApplicationContext(), "In Init", Toast.LENGTH_LONG).show();

        btnMap = (Button) findViewById(R.id.btnMap);

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent intent = new Intent(MainActivity.this, MapActivity.class);
                startActivity(intent);

            }
        });

    }

    public boolean isServicesOk(){

        Log.d(TAG, "isServicesOk: Checking Google Services version");

        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(MainActivity.this);

        if (available == ConnectionResult.SUCCESS){

            // everything is fine
            Log.d(TAG, "isServicesOk: Google play services is avaible");
            return true;

        }else if(GoogleApiAvailability.getInstance().isUserResolvableError(available)){

            // error accure but we can resolve it
            Log.d(TAG, "isServicesOk: an error occure but we can fix it");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(MainActivity.this, available, ERROR_DIALOG_REQUEST);

            dialog.show();

        }else
        {

            Toast.makeText(getApplicationContext(), "Can't make map request", Toast.LENGTH_LONG).show();

        }
        return false;

    }

}
