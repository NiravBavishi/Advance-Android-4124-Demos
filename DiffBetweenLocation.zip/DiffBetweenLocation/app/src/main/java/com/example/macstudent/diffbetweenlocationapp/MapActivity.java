package com.example.macstudent.diffbetweenlocationapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.SphericalUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "MapActivity";

    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 100f;

    private LatLng middle1, middle2, corner1, corner2, corner3, corner4;

    //vars

    private Boolean mLocationPermissionGranted = false;
    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;

    private List<Marker> mListMarkers = new ArrayList<Marker>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        getLocationPermission();

//        Location loc1 = new Location(""), loc2 = new Location("");
//
//        loc1.setLatitude(43.773257);
//        loc1.setLongitude(-79.335899);
//
//        loc2.setLatitude(43.808534);
//        loc2.setLongitude(-79.323208);
//
//        float distanceInMeter =  loc1.distanceTo(loc2);
//
//        Toast.makeText(this, "Distance : " + distanceInMeter, Toast.LENGTH_SHORT).show();

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
    }

    private void drawBounds (LatLngBounds bounds, int color) {
        PolygonOptions polygonOptions =  new PolygonOptions()
                .add(new LatLng(bounds.northeast.latitude, bounds.northeast.longitude))
                .add(new LatLng(bounds.southwest.latitude, bounds.northeast.longitude))
                .add(new LatLng(bounds.southwest.latitude, bounds.southwest.longitude))
                .add(new LatLng(bounds.northeast.latitude, bounds.southwest.longitude))
                .strokeColor(color);


        mMap.addPolygon(polygonOptions);

        Toast.makeText(getApplicationContext(),"draw bounds...",Toast.LENGTH_SHORT).show();
    }

    private void getDeviceLocation() {

        Log.d(TAG, "getDeviceLocation: Getting Current Device Location");

        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        try {

            if (mLocationPermissionGranted) {

                Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {

                        if (task.isSuccessful()) {
                            Log.d(TAG, "onComplete: Found Current Location");
                            Location currentLocation = (Location) task.getResult();
                            moveCamera(new LatLng(43.773257, -79.335899), DEFAULT_ZOOM);

                        } else {

                            Log.d(TAG, "onComplete: Undable To Found Current Location");
                            Toast.makeText(getApplicationContext(), "Unable To Find Current Location", Toast.LENGTH_LONG).show();
                            ;

                        }

                    }
                });

            }

        } catch (SecurityException e) {

            Log.e(TAG, "getDeviceLocation: SecurityException:  " + e.getMessage());


        }

    }

    public void moveCamera(LatLng latLng, Float zoom) {

        Log.d(TAG, "moveCamera: Moving the Camera To lat : " + latLng.latitude + "|| Lng : " + latLng.longitude);

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
        mMap.addMarker(new MarkerOptions().position(latLng));
    }

    private void initMap() {

        Log.d(TAG, "initMap: Initializing Map");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(MapActivity.this);

    }

    private void getLocationPermission() {

        Log.d(TAG, "getLocationPermission: Geting Permisson");

        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};

        if (ContextCompat.checkSelfPermission(this.getApplicationContext(), FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            if (ContextCompat.checkSelfPermission(this.getApplicationContext(), COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                mLocationPermissionGranted = true;
                //intialize map
                initMap();

            } else {

                ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);

            }


        } else {

            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);

        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        mLocationPermissionGranted = false;

        switch (requestCode) {

            case LOCATION_PERMISSION_REQUEST_CODE: {

                if (grantResults.length > 0) {

                    for (int i = 0; i < grantResults.length; i++) {

                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {

                            mLocationPermissionGranted = false;
                            return;

                        }

                    }
                    mLocationPermissionGranted = true;


                }

            }

        }

    }

    public void addMarkers() {
        List<LatLng> positions = new ArrayList<>();

        positions.add(new LatLng(43.773246, -79.335979));

        positions.add(new LatLng(43.773219, -79.335943));

        positions.add(new LatLng(43.773300, -79.335958));

        positions.add(new LatLng(43.773294, -79.335872));

        positions.add(new LatLng(43.773237, -79.335860));

        positions.add(new LatLng(43.773240, -79.335896));

        positions.add(new LatLng(43.773217, -79.335872));

        positions.add(new LatLng(43.773306, -79.335906));

        positions.add(new LatLng(43.773285, -79.335928));

        positions.add(new LatLng(43.773261, -79.335915));

        // Create a LatLngBounds.Builder and include your positions
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
//        for (LatLng position : positions) {
//            mMap.addMarker(new MarkerOptions().position(position));
//        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Toast.makeText(getApplicationContext(), "Map Is Ready", Toast.LENGTH_LONG).show();
        mMap = googleMap;
        if (mLocationPermissionGranted) {

            addMarkers();

            CameraPosition googlePlex = CameraPosition.builder()
                    .target(new LatLng(43.773246, -79.335979))
                    .zoom(20)
                    .bearing(0)
                    .tilt(45)
                    .build();

            mMap.moveCamera(CameraUpdateFactory.newCameraPosition(googlePlex));

            ////////////////
            // The distance you want to increase your square (in meters)
            double distance = 3;

            List<LatLng> positions = new ArrayList<>();

            positions.add(new LatLng(43.773246, -79.335979));

            positions.add(new LatLng(43.773219, -79.335943));

            positions.add(new LatLng(43.773300, -79.335958));

            positions.add(new LatLng(43.773294, -79.335872));

            positions.add(new LatLng(43.773237, -79.335860));

            positions.add(new LatLng(43.773240, -79.335896));

            positions.add(new LatLng(43.773217, -79.335872));

            positions.add(new LatLng(43.773306, -79.335906));

            positions.add(new LatLng(43.773285, -79.335928));

            positions.add(new LatLng(43.773261, -79.335915));

            // Create a LatLngBounds.Builder and include your positions
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            for (LatLng position : positions) {
                builder.include(position);
            }

            // Calculate the bounds of the initial positions
            LatLngBounds initialBounds = builder.build();

            // Increase the bounds by the given distance
            // Notice the distance * Math.sqrt(2) to increase the bounds in the directions of northeast and southwest (45 and 225 degrees respectively)
            LatLng targetNorteast = SphericalUtil.computeOffset(initialBounds.northeast, distance * Math.sqrt(15), 0);
            LatLng targetSouthwest = SphericalUtil.computeOffset(initialBounds.southwest, distance * Math.sqrt(15), 0);

            // Add the new positions to the bounds
            builder.include(targetNorteast);
            builder.include(targetSouthwest);

            // Calculate the bounds of the final positions
            LatLngBounds finalBounds = builder.build();


            double middleLatitude = (finalBounds.northeast.latitude - finalBounds.southwest.latitude) / 2 + finalBounds.southwest.latitude;

            middle1 = new LatLng(middleLatitude, finalBounds.northeast.longitude);
            middle2 = new LatLng(middleLatitude, finalBounds.southwest.longitude);
            corner1 = new LatLng(finalBounds.northeast.latitude, finalBounds.southwest.longitude);
            corner2 = new LatLng(finalBounds.northeast.latitude, finalBounds.northeast.longitude);
            corner3 = new LatLng(finalBounds.southwest.latitude, finalBounds.northeast.longitude);
            corner4 = new LatLng(finalBounds.southwest.latitude, finalBounds.southwest.longitude);

//            mMap.addMarker(new MarkerOptions().position(corner1).title("Corner - 1"));
//            mMap.addMarker(new MarkerOptions().position(corner2).title("Corner - 2"));
//            mMap.addMarker(new MarkerOptions().position(corner3).title("Corner - 3"));
//            mMap.addMarker(new MarkerOptions().position(corner4).title("Corner - 4"));
//            mMap.addMarker(new MarkerOptions().position(middle1).title("Middle - 1"));
//            mMap.addMarker(new MarkerOptions().position(middle2).title("Middle - 2"));

//            Log.e(TAG, "Corner Logs");
//            Log.e(TAG, "Corner - 1: Latitude : " + corner1.latitude + " Longitude : " + corner1.longitude);
//            Log.e(TAG, "Corner - 2 : Latitude : " + corner2.latitude + " Longitude : " + corner2.longitude);
//            Log.e(TAG, "Corner - 3 : Latitude : " + corner3.latitude + " Longitude : " + corner3.longitude);
//            Log.e(TAG, "Corner - 4 : Latitude : " + corner4.latitude + " Longitude : " + corner4.longitude);

            double variation = (corner1.longitude - corner2.longitude) * 0.3;



            Log.e(TAG, "onMapReady: Jail corner - 2 : " + variation);

//            mMap.addMarker(new MarkerOptions().position(new LatLng(corner3.latitude, corner3.longitude + variation)).title("Jail Corner - 2"));
//            mMap.addMarker(new MarkerOptions().position(new LatLng(corner3.latitude + variation, corner3.longitude + variation)).title("Jail Corner - 2"));
//            mMap.addMarker(new MarkerOptions().position(new LatLng(corner3.latitude + variation, corner3.longitude)).title("Jail Corner - 2"));

            LatLng jailCorner12 = new LatLng(corner1.latitude, corner1.longitude - variation);
            LatLng jailCorner13 = new LatLng(corner1.latitude - variation, corner1.longitude - variation);
            LatLng jailCorner14 = new LatLng(corner1.latitude - variation, corner1.longitude);

            LatLng jailCorner32 = new LatLng(corner3.latitude, corner3.longitude + variation);
            LatLng jailCorner33 = new LatLng(corner3.latitude + variation, corner3.longitude + variation);
            LatLng jailCorner34 = new LatLng(corner3.latitude + variation, corner3.longitude);


            addJail(corner1, jailCorner12, jailCorner13, jailCorner14);
            addJail(corner3, jailCorner32, jailCorner33, jailCorner34);

             drawBounds (finalBounds, Color.RED);

            Log.e(TAG, "onMapReady: Field Latitude");
            Log.e(TAG, "onMapReady: Corner 1 : Latitude : " + corner1.latitude + " || Longitude : " + corner1.longitude);
            Log.e(TAG, "onMapReady: Corner 2 : Latitude : " + corner2.latitude + " || Longitude : " + corner2.longitude);
            Log.e(TAG, "onMapReady: Middle 1 : Latitude : " + middle1.latitude + " || Longitude : " + middle1.longitude);
            Log.e(TAG, "onMapReady: Middle 2 : Latitude : " + middle2.latitude + " || Longitude : " + middle2.longitude);



            mMap.addPolyline(
                        new PolylineOptions().add(
                                middle1,
                                middle2
                        ).width(10).color(Color.BLUE).geodesic(true)
                );

            // ge Flag Coordinate
           addFlag();

            //getDeviceLocation();

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mMap.setMyLocationEnabled(true );
        }
    }


    private void addPolylineCustom(LatLng latLng1, LatLng latLng2){

        mMap.addPolyline(
                new PolylineOptions().add(
                        latLng1,
                        latLng2
                ).width(10).color(Color.YELLOW).geodesic(true)
        );

    }

    private void addJail(LatLng latLng1, LatLng latLng2, LatLng latLng3, LatLng latLng4){

        addPolylineCustom(latLng2, latLng3);
        addPolylineCustom(latLng4, latLng3);
        addPolylineCustom(latLng1, latLng4);

    }

    private void addFlag(){

        mMap.addMarker(new MarkerOptions().position(getFlagCoordinate(corner1, middle1)).title("Flag").icon(BitmapDescriptorFactory.fromResource(R.drawable.flag_icon)));
        mMap.addMarker(new MarkerOptions().position(getFlagCoordinate(corner3, middle2)).title("Flag").icon(BitmapDescriptorFactory.fromResource(R.drawable.flag_icon)));


    }

    private LatLng getFlagCoordinate(LatLng latLng1, LatLng latLng2){

        double flagLat, flagLng;


        flagLat = flagCoordinatesLatitude(latLng1.latitude, latLng2.latitude);
        flagLng = flagCoordinatesLongitude(latLng1.longitude, latLng2.longitude);

        return new LatLng(flagLat, flagLng);

    }

    private double flagCoordinatesLatitude(double latitude1, double latitude2){

        double minLatitude, maxLatitude;



        if(latitude1 < latitude2){


            minLatitude = latitude1;
            maxLatitude = latitude2;

        }else if(latitude1 > latitude2){

            minLatitude = latitude2;
            maxLatitude = latitude1;


        }else{

            Log.e(TAG, "flagCoordinates: Invalid Corner Coordinate Please manual Check Error. . .");
            return 0;

        }


        return  getRandomeCoordinate(minLatitude, maxLatitude);


    }


    private double flagCoordinatesLongitude(double longitude1, double longitude2){

        double minLongitude, maxLongitude;



        if(longitude1 < longitude2){


            minLongitude = longitude1;
            maxLongitude = longitude2;

        }else if(longitude1 > longitude2){

            minLongitude = longitude2;
            maxLongitude = longitude1;


        }else{

            Log.e(TAG, "flagCoordinates: Invalid Corner Coordinate Please manual Check Error. . .");
            return 0;

        }


        return  getRandomeCoordinate(minLongitude, maxLongitude);


    }



    private double getRandomeCoordinate(double min, double max){

        Random r = new Random();

       double flagLatitude = min + (max - min) * r.nextDouble();

        if(flagLatitude < max && flagLatitude > min){

            return flagLatitude;

        }else{

            return getRandomeCoordinate(min, max);

        }

    }

}