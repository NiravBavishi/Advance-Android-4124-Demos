package com.example.niravbavishi.firebasedemo;

public class User {

    public String name;
    public String mail;

    public User(){



    }

    public User(String name, String mail) {
        this.name = name;
        this.mail = mail;
    }
}
