package com.example.niravbavishi.firebasedemo;

public class Message {

    public String name;
    public String message;
    public String date;

    public Message() {
    }

    public Message(String name, String message, String date) {
        this.name = name;
        this.message = message;
        this.date = date;
    }
}
