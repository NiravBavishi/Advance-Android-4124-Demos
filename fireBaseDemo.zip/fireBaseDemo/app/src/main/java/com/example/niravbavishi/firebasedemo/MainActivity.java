package com.example.niravbavishi.firebasedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference root;


    TextView textView;
    Button btn;
    EditText msgText;


    private ChildEventListener childEventListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



         textView = findViewById(R.id.textView);
         btn = findViewById(R.id.sendBtn);
         msgText = findViewById(R.id.messageText);



        database = FirebaseDatabase.getInstance();
        root = database.getReference();


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Test", Toast.LENGTH_LONG).show();

                Date d = new Date();
                SimpleDateFormat s = new SimpleDateFormat("hh:mm a");
                String date = s.format(d);

                String messagetext = msgText.getText().toString();

                if (messagetext.trim() != "" || messagetext.trim() != null) {

                    Message msg = new Message("Nirav", msgText.getText().toString(), date);

                    root.child("Message").push().setValue(msg);

                }else
                {

                    Toast.makeText(getApplicationContext(), "Please Write Something", Toast.LENGTH_LONG).show();

                }

                msgText.setText(null);

            }
        });



        attachMessage();

//
//        User user1 = new User("Nirav", "niravbavishi007@gmail.com");
//
//        root.child("users").push().setValue(user1);

    }


    public void attachMessage(){

        if(childEventListener == null){

            childEventListener = new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                    Message msg1 = dataSnapshot.getValue(Message.class);
                    String txt = msg1.date + ": " + msg1.name + " says: " + msg1.message + "\n";

                    textView.append(txt);

                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            };

            root.child("Message").addChildEventListener(childEventListener);

        }




    }





}
