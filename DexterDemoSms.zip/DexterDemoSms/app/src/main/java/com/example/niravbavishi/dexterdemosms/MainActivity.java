package com.example.niravbavishi.dexterdemosms;

import android.Manifest;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import android.telephony.SmsManager;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

public class MainActivity extends AppCompatActivity {


    private EditText edtPhoneNumber, edtMessageText;
    private Button btnSend;
    private TextView txtViewStatus;

    private PermissionListener sendSMSPermissionListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edtPhoneNumber = (EditText) findViewById(R.id.edtPhoneNumber);
        edtMessageText = (EditText) findViewById(R.id.edtMessageText);
        btnSend = (Button) findViewById(R.id.btnSendText);
        txtViewStatus = (TextView) findViewById(R.id.txtViewStatus);


        createPermissionListner();

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.e("Error", "onClick: Tag - 1 ");

                Dexter.withActivity(MainActivity.this)
                        .withPermission(Manifest.permission.SEND_SMS)
                        .withListener(sendSMSPermissionListener)
                        .check();
                Log.e("Error", "onClick: Tag - 2 ");

                SmsManager smsManager = SmsManager.getDefault();
                Log.e("Error", "onClick: Tag - 3 ");

                String PhoneNumber = edtPhoneNumber.getText().toString();
                String messageText = edtMessageText.getText().toString();

                smsManager.sendTextMessage(PhoneNumber, null, messageText, null, null);
                Log.e("Error", "onClick: Tag - 4 ");

                txtViewStatus.setText("Message Sent. . .");

            }
        });


    }


    public void createPermissionListner(){

        if (sendSMSPermissionListener == null){

            sendSMSPermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {

                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {

                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {

                    token.continuePermissionRequest();

                }
            };

        }

    }

}
